import Home from '../../components/Home/home';

const HomePage = () => {
	return <Home />;
};

export default HomePage;

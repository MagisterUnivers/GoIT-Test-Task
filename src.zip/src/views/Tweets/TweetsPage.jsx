import Tweets from '../../components/Tweets/tweets';

const TweetsPage = () => {
	return <Tweets />;
};

export default TweetsPage;

import NotFound from '../../components/Notfound/notfound';

const NotFoundPage = () => {
	return <NotFound />;
};

export default NotFoundPage;

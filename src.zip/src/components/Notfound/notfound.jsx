const NotFound = () => {};

export default NotFound;
